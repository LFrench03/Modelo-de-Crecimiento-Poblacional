# Modelo Predictivo del Crecimiento Urbano
---

![](img/cuba1.jpeg)

###### Imagen generada por [IA](https://copilot.microsoft.com/images/create?)